import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * calculate square root within 0.01% error.
 *
 * @author Saleh Zakzok
 *
 */
public final class Newton1 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton1() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @return estimate of square root
     */
    private static double sqrt(double x) {
        /*
         * Put your code for myMethod here
         */
        // constant double for our percentage error
        final double epsilon = 0.0001;
        // we assume the square root of x is itself
        double squareRoot = x;

        SimpleWriter out = new SimpleWriter1L();
        SimpleReader in = new SimpleReader1L();
        double rootSquare = Math.abs((squareRoot * squareRoot) - x / x);

        while (rootSquare >= (epsilon * epsilon)) {
            squareRoot = ((squareRoot + x / squareRoot)) / 2;
            if (Math.abs(squareRoot - x) < epsilon) {
                break;
            }

        }
        in.close();
        out.close();

        return squareRoot;

    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Put your main program code here; it may call myMethod as shown
         */
        out.println("Would you like to compute a square root? (Reply with y or n)");
        String decision = in.nextLine();
        out.println("Please enter a positive double: ");
        double number = in.nextDouble();

        while (decision.equals("y")) {
            sqrt(number);
            out.println("Would you like to compute a square root? (Reply with y or n)");
            decision = in.nextLine();
            out.println("Please enter a positive double: ");
            number = in.nextDouble();
        }
        while (decision.equals("n")) {
            break;
        }
        double answer = sqrt(number);
        out.println(answer);

        /*
         * Close input and output streams
         */
        in.close();
        out.close();

    }
}
