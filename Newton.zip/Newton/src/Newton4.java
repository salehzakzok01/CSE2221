import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Put a short phrase describing the program here.
 *
 * @author Saleh Zakzok
 *
 */
public final class Newton4 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Newton4() {
    }

    /**
     * Computes estimate of square root of x to within relative error 0.01%.
     *
     * @param x
     *            positive number to compute square root of
     * @return estimate of square root
     * @param epsilon
     *              this is the error range of the square root
     */
    private static double sqrt(double x, double epsilon) {
        /*
         * Put your code for myMethod here
         */
        final double half = 0.5;
        double root = x;
        if (root == 0) {
            return 0;
        } else {
        double rootEstimate = half * (x / root + root);
        while ((((Math.pow(rootEstimate, 2) - root) / root) > Math.pow(epsilon, 2))) {
            rootEstimate = half * (root / rootEstimate + rootEstimate);
        }
        return rootEstimate;
    }
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Put your main program code here; it may call myMethod as shown
         */
        double input = 0;
        double squareRoot = 0;
        double epsilon = 0;
        out.println("Do you want to calculate a square root? 'y' is yes, no is any other key");
        String answer = in.nextLine();
        if (answer.equals("y") || answer.equals("Y")) {
            out.println("Enter an error range value (epsilon): ");
            epsilon = in.nextDouble();
            out.println("Enter a positive number: ");
            input = in.nextDouble();
            do {
                squareRoot = sqrt(input, epsilon);
                out.println("The square root of " + input + " is " + squareRoot);
                out.println("Enter a positive number: ");
                input = in.nextDouble();
            } while (input >= 0);
        }
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
