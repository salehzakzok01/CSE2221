import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Ask the user what constant to approximate and then ask
 * for each of the four numbers w, x, y, z. The program will then
 * calculate and report the values of the exponents a, b, c, d using
 * the De Jager as close as possible to the constant, as well as the
 * value of the formula and relative error of approximation
 *
 * @author Saleh Zakzok
 *
 */
public final class ABCDGuesser2 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser2() {
    }
    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        out.println("Please enter a positive number: ");
        String userInput = in.nextLine();
        boolean canParseDouble = FormatChecker.canParseDouble(userInput);
        while (!canParseDouble) {
            out.println("Please enter a positive number: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
        }
        double positiveDouble = Double.parseDouble(userInput);
        while (positiveDouble < 0) {
            out.println("Please enter a positive number: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
            positiveDouble = Double.parseDouble(userInput);
        }
        return positiveDouble;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in, SimpleWriter out) {
        out.println("Please enter a positive number that is not 1: ");
        String userInput = in.nextLine();
        boolean canParseDouble = FormatChecker.canParseDouble(userInput);
        while (!canParseDouble) {
            out.println("Please enter a positive number that is not 1: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
        }
        double notOne = Double.parseDouble(userInput);
        while (notOne <= 0 || notOne == 1) {
            out.println("Please enter a positive number that is not 1: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
            notOne = Double.parseDouble(userInput);
        }
        return notOne;
    }

    /**
     * This method will approximate insert constant within a certain error.
     *
     * @param constant
     *          constant to be calculated
     * @param w
     *          one of the four numbers entered by user
     * @param x
     *          one of the four numbers entered by user
     * @param y
     *          one of the four numbers entered by user
     * @param z
     *          one of the four numbers entered by user
     * @param out
     *          output stream
     */
    private static void myMethod(double constant, double w, double x, double y,
            double z, SimpleWriter out) {
        int a = 0, b = 0, c = 0, d = 0;
        double acount = 0, bcount = 0, ccount = 0, dcount = 0;
        double[] deJager = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3, -1.0 / 4, 0,
                1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };
        double difference = ((Math.pow(w, deJager[0])) * (Math.pow(x, deJager[0]))
                * (Math.pow(y, deJager[0])) * (Math.pow(z, deJager[0])))
                - constant;
        while (d < deJager.length) {
            while (c < deJager.length) {
                while (b < deJager.length) {
                    while (a < deJager.length) {
                        double estimate = ((Math.pow(w, deJager[a]))
                                * (Math.pow(x, deJager[b]))
                                * (Math.pow(y, deJager[c])) * (Math.pow(z,
                                deJager[d]))) - constant;
                        if (Math.abs(estimate) < Math.abs(difference)) {
                            difference = estimate;
                            acount = deJager[a];
                            bcount = deJager[b];
                            ccount = deJager[c];
                            dcount = deJager[d];
                        }
                        a++;
                    }
                    b++;
                    a = 0;
                }
                c++;
                b = 0;
            }
            d++;
            c = 0;
        }
        double error = (difference / constant) * 100;
        System.out.println(constant + difference);
        System.out.println("The error is: " + error + "%");
        System.out.println("The exponent of the first number you chose was "
                + acount);
        System.out.println("The exponent of the second number you chose was "
                + bcount);
        System.out.println("The exponent of the third number you chose was "
                + ccount);
        System.out.println("The exponent of the fourth number you chose was "
                + dcount);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Put your main program code here; it may call myMethod as shown
         */
        out.println("Please enter a constant to approximate");
        double constant = getPositiveDouble(in, out);
        out.println("Please enter four positive numbers that are not one");
        double w = getPositiveDoubleNotOne(in, out);
        double x = getPositiveDoubleNotOne(in, out);
        double y = getPositiveDoubleNotOne(in, out);
        double z = getPositiveDoubleNotOne(in, out);
        myMethod(constant, w, x, y, z, out);
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
