import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.utilities.FormatChecker;

/**
 * Ask the user what constant to approximate and then ask
 * for each of the four numbers w, x, y, z. The program will then
 * calculate and report the values of the exponents a, b, c, d using
 * the De Jager as close as possible to the constant, as well as the
 * value of the formula and relative error of approximation
 *
 * @author Saleh Zakzok
 *
 */
public final class ABCDGuesser1 {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private ABCDGuesser1() {
    }
    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number entered by the user
     */
    private static double getPositiveDouble(SimpleReader in, SimpleWriter out) {
        out.println("Please enter a positive number: ");
        String userInput = in.nextLine();
        boolean canParseDouble = FormatChecker.canParseDouble(userInput);
        while (!canParseDouble) {
            out.println("Please enter a positive number: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
        }
        double positiveDouble = Double.parseDouble(userInput);
        while (positiveDouble < 0) {
            out.println("Please enter a positive number: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
            positiveDouble = Double.parseDouble(userInput);
        }
        return positiveDouble;
    }

    /**
     * Repeatedly asks the user for a positive real number not equal to 1.0
     * until the user enters one. Returns the positive real number.
     *
     * @param in
     *            the input stream
     * @param out
     *            the output stream
     * @return a positive real number not equal to 1.0 entered by the user
     */
    private static double getPositiveDoubleNotOne(SimpleReader in, SimpleWriter out) {
        out.println("Please enter a positive number that is not 1: ");
        String userInput = in.nextLine();
        boolean canParseDouble = FormatChecker.canParseDouble(userInput);
        while (!canParseDouble) {
            out.println("Please enter a positive number that is not 1: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
        }
        double notOne = Double.parseDouble(userInput);
        while (notOne <= 0 || notOne == 1) {
            out.println("Please enter a positive number that is not 1: ");
            userInput = in.nextLine();
            canParseDouble = FormatChecker.canParseDouble(userInput);
            notOne = Double.parseDouble(userInput);
        }
        return notOne;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        /*
         * Put your main program code here; it may call myMethod as shown
         */
        out.println("Please enter a constant to approximate");
        double constant = getPositiveDouble(in, out);
        out.println("Please enter four positive numbers that are not one");
        double w = getPositiveDoubleNotOne(in, out);
        double x = getPositiveDoubleNotOne(in, out);
        double y = getPositiveDoubleNotOne(in, out);
        double z = getPositiveDoubleNotOne(in, out);

        double newEstimate = 0;
        double a = 0.0, b = 0.0, c = 0.0, d = 0.0;
        int i = 0, j = 0, k = 0, n = 0;
        double error = 0;
        double[] deJager = { -5, -4, -3, -2, -1, (double) -1 / 2,
                (double) -1 / 3, (double) -1 / 4, 0, (double) 1 / 4,
                (double) 1 / 3, (double) 1 / 2, 1, 2, 3, 4, 5 };


        // use nested while loops to determine values for a, b, c, and d
        while (i < deJager.length) {
            j = 0;
            while (j < deJager.length) {
                k = 0;
                while (k < deJager.length) {
                    n = 0;
                    while (n < deJager.length) {
                        a = deJager[i];
                        b = deJager[j];
                        c = deJager[k];
                        d = deJager[n];

                        newEstimate = Math.pow(w, a) * Math.pow(x, b)
                                * Math.pow(y, c) * Math.pow(z, d);
                        if (constant > newEstimate) {
                            error = (((constant - newEstimate) / constant) * 100);
                            if (error < 0.1) {
                                out.println(
                                        "The values of a, b, c, and d are: ");
                                out.println("a: " + a + " b: " + b + " c: " + c
                                        + " d: " + d);
                                out.println(
                                        "The approximated value of the constant within "
                                                + error + "% error is "
                                                + newEstimate + ".");
                            }
                        } else {
                            error = (((newEstimate - constant) / constant) * 100);
                            if (error < 0.1) {
                                out.println(
                                        "The values of a, b, c, and d are: ");
                                out.println("a: " + a + " b: " + b + " c: " + c
                                        + " d: " + d);
                                out.println(
                                        "The approximated value of the constant within "
                                                + error + "% error is "
                                                + newEstimate + ".");
                            }
                        }
                        n++;
                    }
                    k++;
                }
                j++;
            }
            i++;
        }
        /*
         * Close input and output streams
         */
        in.close();
        out.close();
    }

}
